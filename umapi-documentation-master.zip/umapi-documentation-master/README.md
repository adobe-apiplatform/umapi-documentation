# umapi-documentation: User Management API Documentation from Adobe

This documentation is open source, maintained by Adobe, and distributed under the terms
of the OSI-approved MIT license.  See the LICENSE file for details.

Copyright (c) 2016-2023 Adobe Systems Incorporated.

https://developer.adobe.com/umapi/


