Number of users assigned to a product profile.
