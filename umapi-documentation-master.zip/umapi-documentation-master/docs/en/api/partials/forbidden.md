### <a name="{{ include.anchor }}" class="api-ref-subtitle">403 Forbidden</a>
Possible causes are:
- Missing API key.
- The organization is currently migrating. Either from DMA or to One Console.
- API key is not permitted access.

```
< HTTP/1.1 403 Forbidden
< Date: Thu, 22 Jun 2017 09:41:22 GMT
< X-Request-Id: user-assigned-request-id
< Content-Length: 0
< Connection: keep-alive
```