The unique identifier for the admin group of a product profile.
