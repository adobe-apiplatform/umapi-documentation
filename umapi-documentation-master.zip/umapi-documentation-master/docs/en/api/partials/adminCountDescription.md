The number of admins assigned to a profile.
