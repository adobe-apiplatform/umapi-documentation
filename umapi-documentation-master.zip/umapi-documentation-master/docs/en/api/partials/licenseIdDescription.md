The unique identifier for a product profile.
